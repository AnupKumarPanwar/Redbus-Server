<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
</head>
<body>

	<form action="http://localhost/zomato/addCategory.php" method="POST" enctype="multipart/form-data">
		<input type="text" name="categoryName">
		<input type="file" name="imageToUpload">
		<input type="submit" name="submit">
	</form>

</body>
</html>