<!DOCTYPE html>
<html>
<head>
	<title>404 - Page not found</title>
</head>
<style type="text/css">
	html, body {
	    height: 100%;
	    background: #f5ef99;
	}
	.main {
	    height: 100%;
	    width: 100%;
	    display: table;
	}
	.wrapper {
	    display: table-cell;
	    height: 100%;
	    vertical-align: middle;
	}

</style>
<body style="text-align: center; height: 100%;">
	<div class = "main">
	<div class = "wrapper">
	    <img src="./xL1M1914.jpg" style="height: 90vh;">	
	</div>
	</div>
</body>
</html>